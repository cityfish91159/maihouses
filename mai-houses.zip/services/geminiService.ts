import { GoogleGenAI, Type, FunctionDeclaration } from "@google/genai";

const apiKey = process.env.API_KEY;

const ai = new GoogleGenAI({ apiKey: apiKey });

// Tool definition for filtering properties
const filterPropertiesTool: FunctionDeclaration = {
  name: 'filterProperties',
  description: 'Filter real estate properties based on user criteria. Call this when the user asks to see specific types of houses or locations.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      location: {
        type: Type.STRING,
        description: 'The city or district to filter by (e.g., "Taipei", "Xinyi District").',
      },
      minPrice: {
        type: Type.NUMBER,
        description: 'Minimum price budget.',
      },
      maxPrice: {
        type: Type.NUMBER,
        description: 'Maximum price budget.',
      },
      minBeds: {
        type: Type.NUMBER,
        description: 'Minimum number of bedrooms required.',
      },
      propertyType: {
        type: Type.STRING,
        description: 'Type of property: House, Apartment, Condo, Villa.',
        enum: ['House', 'Apartment', 'Condo', 'Villa']
      }
    },
  },
};

export const createChatSession = () => {
  return ai.chats.create({
    model: 'gemini-2.5-flash',
    config: {
      systemInstruction: `你是 Mai House 的 AI 房產顧問「Mai」。
      你的目標是協助使用者在我們的列表中找到夢想中的家。
      你可以使用工具 'filterProperties' 來篩選網站上的房源顯示。
      請務必使用**繁體中文 (Traditional Chinese)** 回答。
      如果使用者提到地點、價格、臥室數量或房產類型，請務必調用 'filterProperties' 工具。
      如果使用者只是打招呼或問一般問題，請禮貌地回答。
      保持回答簡潔、專業且親切。適度使用表情符號。
      不要向使用者提及內部函數名稱。當你完成篩選時，可以說「我已經為您更新了房源列表」。`,
      tools: [{ functionDeclarations: [filterPropertiesTool] }],
    }
  });
};

export const generatePropertyDescription = async (propertyTitle: string, location: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: `為位於 ${location} 的 ${propertyTitle} 寫一段簡短吸引人的 2 句行銷文案，使用繁體中文。`,
  });
  return response.text;
}