import { Property } from './types';

export const PROPERTIES: Property[] = [
  {
    id: '1',
    title: '現代極簡風獨棟別墅',
    price: 38500000,
    location: '台北市, 信義區',
    beds: 4,
    baths: 3.5,
    sqft: 89,
    type: 'Villa',
    imageUrl: 'https://picsum.photos/id/10/800/600',
    description: '令人驚嘆的現代別墅，採開放式格局，擁有落地窗與私人泳池，盡享奢華生活。',
    featured: true
  },
  {
    id: '2',
    title: '市中心豪華景觀公寓',
    price: 22800000,
    location: '新北市, 板橋區',
    beds: 2,
    baths: 2,
    sqft: 45,
    type: 'Apartment',
    imageUrl: 'https://picsum.photos/id/12/800/600',
    description: '位於市中心的工業風雅寓。挑高天花板，裸露磚牆設計，配備頂級家電。'
  },
  {
    id: '3',
    title: '溫馨花園鄉村小屋',
    price: 15600000,
    location: '宜蘭縣, 羅東鎮',
    beds: 3,
    baths: 2,
    sqft: 55,
    type: 'House',
    imageUrl: 'https://picsum.photos/id/16/800/600',
    description: '被大自然環繞的迷人小屋。擁有寬敞的花園、壁爐以及全新翻修的廚房。'
  },
  {
    id: '4',
    title: '海景第一排度假宅',
    price: 28500000,
    location: '高雄市, 鼓山區',
    beds: 2,
    baths: 2,
    sqft: 38,
    type: 'Condo',
    imageUrl: 'https://picsum.photos/id/28/800/600',
    description: '每個房間都能欣賞令人屏息的海景。設施包括健身房、游泳池和 24 小時保全。',
    featured: true
  },
  {
    id: '5',
    title: '優質學區家庭住宅',
    price: 19800000,
    location: '台中市, 西屯區',
    beds: 4,
    baths: 3,
    sqft: 72,
    type: 'House',
    imageUrl: 'https://picsum.photos/id/57/800/600',
    description: '位於安靜社區的完美家庭住宅。鄰近頂尖學校與公園，生活機能極佳。'
  },
  {
    id: '6',
    title: '山林隱居豪華別墅',
    price: 45000000,
    location: '南投縣, 魚池鄉',
    beds: 5,
    baths: 4,
    sqft: 110,
    type: 'Villa',
    imageUrl: 'https://picsum.photos/id/77/800/600',
    description: '奢華的山林度假別墅。設有熱水按摩池、家庭劇院和主廚級廚房。'
  },
  {
    id: '7',
    title: '經典復古透天厝',
    price: 26000000,
    location: '台南市, 中西區',
    beds: 4,
    baths: 3.5,
    sqft: 82,
    type: 'House',
    imageUrl: 'https://picsum.photos/id/102/800/600',
    description: '經過精心修復的經典建築，保留了原始細節並融入現代化更新。'
  },
  {
    id: '8',
    title: '綠能環保現代宅',
    price: 21500000,
    location: '新竹縣, 竹北市',
    beds: 3,
    baths: 2.5,
    sqft: 58,
    type: 'House',
    imageUrl: 'https://picsum.photos/id/164/800/600',
    description: '極致的永續生活體驗。配備太陽能板、雨水回收系統與節能設計。'
  }
];