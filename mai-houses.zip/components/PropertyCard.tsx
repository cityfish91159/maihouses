import React from 'react';
import { Property } from '../types';
import { Bed, Bath, Maximize, MapPin, Heart } from 'lucide-react';

interface PropertyCardProps {
  property: Property;
  onClick: (property: Property) => void;
}

const PropertyCard: React.FC<PropertyCardProps> = ({ property, onClick }) => {
  // Helper to translate property types
  const getPropertyTypeLabel = (type: string) => {
    switch (type) {
      case 'House': return '透天/別墅';
      case 'Apartment': return '公寓';
      case 'Condo': return '電梯大樓';
      case 'Villa': return '豪華別墅';
      default: return type;
    }
  };

  return (
    <div 
      className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer border border-gray-100 flex flex-col h-full"
      onClick={() => onClick(property)}
    >
      <div className="relative h-64 overflow-hidden">
        <img 
          src={property.imageUrl} 
          alt={property.title} 
          className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm p-2 rounded-full shadow-sm hover:bg-red-50 transition-colors">
          <Heart className="h-5 w-5 text-gray-600 hover:text-red-500 hover:fill-red-500 transition-colors" />
        </div>
        <div className="absolute top-4 left-4">
          <span className="px-3 py-1 bg-primary-600/90 backdrop-blur-sm text-white text-xs font-bold uppercase tracking-wider rounded-full">
            {getPropertyTypeLabel(property.type)}
          </span>
        </div>
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-4">
          <p className="text-white font-bold text-xl">NT$ {property.price.toLocaleString()}</p>
        </div>
      </div>
      
      <div className="p-5 flex flex-col flex-grow">
        <div className="flex items-start justify-between mb-2">
            <h3 className="text-lg font-bold text-gray-900 line-clamp-1">{property.title}</h3>
        </div>
        
        <div className="flex items-center text-gray-500 mb-4 text-sm">
          <MapPin className="h-4 w-4 mr-1 flex-shrink-0" />
          <span className="truncate">{property.location}</span>
        </div>

        <div className="flex items-center justify-between mt-auto pt-4 border-t border-gray-100 text-sm text-gray-600">
          <div className="flex items-center gap-1">
            <Bed className="h-4 w-4 text-primary-500" />
            <span className="font-medium">{property.beds}</span> <span className="hidden xs:inline">房</span>
          </div>
          <div className="flex items-center gap-1">
            <Bath className="h-4 w-4 text-primary-500" />
            <span className="font-medium">{property.baths}</span> <span className="hidden xs:inline">衛</span>
          </div>
          <div className="flex items-center gap-1">
            <Maximize className="h-4 w-4 text-primary-500" />
            <span className="font-medium">{property.sqft}</span> <span className="hidden xs:inline">坪</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PropertyCard;