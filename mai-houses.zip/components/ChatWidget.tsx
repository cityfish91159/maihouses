import React, { useState, useRef, useEffect } from 'react';
import { Send, X, MessageSquare, Sparkles, Loader2, Bot } from 'lucide-react';
import { ChatMessage, FilterCriteria } from '../types';
import { createChatSession } from '../services/geminiService';
import ReactMarkdown from 'react-markdown';
import { Chat } from '@google/genai';

interface ChatWidgetProps {
  isOpen: boolean;
  onClose: () => void;
  onFilterUpdate: (criteria: FilterCriteria) => void;
}

const ChatWidget: React.FC<ChatWidgetProps> = ({ isOpen, onClose, onFilterUpdate }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { id: '0', role: 'model', text: "您好！我是 Mai。我可以幫您找到理想的家。您可以試著說「幫我找台北市的兩房公寓」。" }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatSessionRef = useRef<Chat | null>(null);

  useEffect(() => {
    if (isOpen && !chatSessionRef.current) {
      chatSessionRef.current = createChatSession();
    }
  }, [isOpen]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || !chatSessionRef.current) return;

    const userMessage: ChatMessage = { id: Date.now().toString(), role: 'user', text: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const result = await chatSessionRef.current.sendMessage({ message: userMessage.text });
      
      // Check for tool calls in the response
      const functionCalls = result.functionCalls;
      
      let responseText = result.text;

      if (functionCalls && functionCalls.length > 0) {
          // Handle tool calls
          const functionResponses: any[] = [];

          for (const call of functionCalls) {
              if (call.name === 'filterProperties') {
                  const args = call.args as FilterCriteria;
                  console.log("Filtering with:", args);
                  onFilterUpdate(args);
                  
                  functionResponses.push({
                      id: call.id,
                      name: call.name,
                      response: { result: 'success', filtered: true }
                  });
              }
          }
          
          // Send tool response back to model to get final text
          if (functionResponses.length > 0) {
              const toolResult = await chatSessionRef.current.sendToolResponse({ functionResponses });
              responseText = toolResult.text;
          }
      }

      const botMessage: ChatMessage = { 
        id: (Date.now() + 1).toString(), 
        role: 'model', 
        text: responseText || "我已經為您更新了房源列表。" 
      };
      setMessages(prev => [...prev, botMessage]);

    } catch (error) {
      console.error('Chat error:', error);
      setMessages(prev => [...prev, { id: Date.now().toString(), role: 'model', text: "目前連線發生問題，請稍後再試。" }]);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed bottom-4 right-4 w-full max-w-md bg-white rounded-2xl shadow-2xl z-50 flex flex-col border border-gray-200 sm:w-[400px] h-[600px] max-h-[80vh] overflow-hidden font-sans animate-in slide-in-from-bottom-10 fade-in duration-300">
      {/* Header */}
      <div className="bg-primary-900 p-4 flex items-center justify-between text-white">
        <div className="flex items-center gap-2">
          <div className="bg-white/10 p-2 rounded-full">
            <Sparkles className="h-5 w-5 text-yellow-300" />
          </div>
          <div>
            <h3 className="font-bold text-lg">Mai 智慧助手</h3>
            <p className="text-xs text-primary-200">AI 房產顧問</p>
          </div>
        </div>
        <button onClick={onClose} className="text-white/80 hover:text-white transition-colors">
          <X className="h-6 w-6" />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 bg-gray-50 space-y-4 scrollbar-hide">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm shadow-sm ${
              msg.role === 'user' 
                ? 'bg-primary-600 text-white rounded-br-none' 
                : 'bg-white text-gray-800 border border-gray-100 rounded-bl-none'
            }`}>
              {msg.role === 'model' ? (
                <ReactMarkdown 
                    className="prose prose-sm max-w-none prose-p:m-0 prose-ul:m-0 prose-li:m-0"
                    components={{
                        p: ({node, ...props}) => <p className="mb-2 last:mb-0" {...props} />
                    }}
                >
                    {msg.text}
                </ReactMarkdown>
              ) : (
                msg.text
              )}
            </div>
          </div>
        ))}
        {isLoading && (
           <div className="flex justify-start">
            <div className="bg-white border border-gray-100 rounded-2xl rounded-bl-none px-4 py-3 shadow-sm">
              <div className="flex gap-1">
                <div className="w-2 h-2 bg-primary-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <div className="w-2 h-2 bg-primary-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <div className="w-2 h-2 bg-primary-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-4 bg-white border-t border-gray-100">
        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="詢問 Mai 關於房源..."
            className="flex-1 border border-gray-200 rounded-full px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
            disabled={isLoading}
          />
          <button 
            onClick={handleSend}
            disabled={isLoading || !input.trim()}
            className="bg-primary-600 text-white p-2 rounded-full hover:bg-primary-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Send className="h-5 w-5" />}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatWidget;