import React, { useState, useMemo } from 'react';
import Navbar from './components/Navbar';
import PropertyCard from './components/PropertyCard';
import ChatWidget from './components/ChatWidget';
import { PROPERTIES } from './constants';
import { Property, FilterCriteria } from './types';
import { Search, MapPin, SlidersHorizontal, X, Bot, Brain, Shield, Zap, Star, ArrowRight, CheckCircle } from 'lucide-react';

function App() {
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  
  // Filtering State
  const [filters, setFilters] = useState<FilterCriteria>({});
  const [searchQuery, setSearchQuery] = useState('');

  const handleChatToggle = () => setIsChatOpen(!isChatOpen);

  const handleFilterUpdate = (newFilters: FilterCriteria) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
  };

  const handleHeroSearch = () => {
    const listingsSection = document.getElementById('listings');
    if (listingsSection) {
        listingsSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const filteredProperties = useMemo(() => {
    return PROPERTIES.filter(p => {
      // Text Search (Title or Location)
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        if (!p.title.toLowerCase().includes(q) && !p.location.toLowerCase().includes(q)) {
            return false;
        }
      }

      // Gemini Tool Filters
      if (filters.location && !p.location.toLowerCase().includes(filters.location.toLowerCase())) return false;
      if (filters.minPrice && p.price < filters.minPrice) return false;
      if (filters.maxPrice && p.price > filters.maxPrice) return false;
      if (filters.minBeds && p.beds < filters.minBeds) return false;
      if (filters.propertyType && p.type.toLowerCase() !== filters.propertyType.toLowerCase()) return false;

      return true;
    });
  }, [filters, searchQuery]);

  const activeFilterCount = Object.keys(filters).length;

  const clearFilters = () => {
      setFilters({});
      setSearchQuery('');
  };
  
  // Helper to translate property types for the modal
  const getPropertyTypeLabel = (type: string) => {
    switch (type) {
      case 'House': return '透天/別墅';
      case 'Apartment': return '公寓';
      case 'Condo': return '電梯大樓';
      case 'Villa': return '豪華別墅';
      default: return type;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 font-sans text-gray-900">
      <Navbar onChatToggle={() => setIsChatOpen(true)} />

      {/* Hero Section */}
      <section className="relative bg-primary-900 h-[600px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 opacity-30">
          <img 
            src="https://images.unsplash.com/photo-1600596542815-2495db98dada?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80" 
            alt="Hero background" 
            className="w-full h-full object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-primary-900/50 via-primary-900/80 to-primary-900"></div>
        
        <div className="relative z-10 max-w-5xl w-full px-4 flex flex-col items-center text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary-800/50 border border-primary-700 text-primary-200 text-sm font-medium mb-6 backdrop-blur-sm animate-fade-in-up">
            <SparklesIcon className="w-4 h-4 text-yellow-400" />
            <span>由 Gemini AI 2.0 驅動</span>
          </div>
          
          <h1 className="text-4xl md:text-7xl font-bold text-white mb-6 tracking-tight leading-tight">
            買房，<br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary-200 to-white">重新定義。</span>
          </h1>
          
          <p className="text-xl text-primary-100 mb-10 max-w-2xl mx-auto font-light leading-relaxed">
            體驗未來的購屋方式。讓我們的智能助手引導您探索市場，找到與您生活方式完美契合的家。
          </p>
          
          <div className="w-full max-w-3xl bg-white p-2 rounded-2xl shadow-2xl flex items-center transform transition-transform focus-within:scale-105 duration-300">
            <div className="pl-4 text-gray-400">
              <Search className="h-6 w-6" />
            </div>
            <input 
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleHeroSearch()}
              placeholder="您想住在哪個城市？"
              className="flex-1 px-4 py-4 text-gray-900 placeholder-gray-400 focus:outline-none text-lg bg-transparent"
            />
            <button 
                className="bg-primary-600 text-white px-8 py-4 rounded-xl font-medium hover:bg-primary-700 transition-colors shadow-lg hidden sm:block"
                onClick={handleHeroSearch}
            >
              搜尋
            </button>
          </div>
          
          <div className="mt-8 flex items-center gap-6 text-primary-200 text-sm font-medium">
            <span className="flex items-center gap-2"><CheckCircle className="h-4 w-4 text-green-400"/> 智慧估價</span>
            <span className="flex items-center gap-2"><CheckCircle className="h-4 w-4 text-green-400"/> 真實房源</span>
            <span className="flex items-center gap-2"><CheckCircle className="h-4 w-4 text-green-400"/> 線上賞屋</span>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-white border-b border-gray-100 relative z-20 -mt-8 mx-4 md:mx-auto max-w-6xl rounded-2xl shadow-lg p-8 grid grid-cols-2 md:grid-cols-4 gap-8">
         {[
            { label: '在售物件', value: '2,400+' },
            { label: '服務城市', value: '85' },
            { label: '每日媒合', value: '150+' },
            { label: '滿意屋主', value: '1.2萬+' }
        ].map((stat, idx) => (
            <div key={idx} className="text-center md:border-r border-gray-100 last:border-0">
                <div className="text-3xl md:text-4xl font-bold text-primary-600 mb-1">{stat.value}</div>
                <div className="text-gray-500 text-xs md:text-sm font-semibold uppercase tracking-wider">{stat.label}</div>
            </div>
        ))}
      </section>

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        
        {/* Section: Why Choose Mai */}
        <div className="mb-24">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-base text-primary-600 font-semibold tracking-wide uppercase mb-2">為什麼選擇 Mai House?</h2>
            <p className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">智慧與直覺的完美結合。</p>
            <p className="text-lg text-gray-500">我們結合先進的 AI 技術與深度市場數據，簡化您的購屋旅程。</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <FeatureCard 
              icon={<Brain className="h-8 w-8 text-white" />}
              title="AI 智能媒合"
              desc="我們的 Gemini 引擎能理解您的自然語言，不只是篩選條件，而是根據您的生活風格與「氛圍」推薦房源。"
            />
            <FeatureCard 
              icon={<Shield className="h-8 w-8 text-white" />}
              title="嚴格房源審核"
              desc="每一筆房源皆經過我們的信任團隊審核。智慧合約確保您的交易過程安全透明。"
            />
            <FeatureCard 
              icon={<Zap className="h-8 w-8 text-white" />}
              title="即時房源通知"
              desc="搶先一步。當符合您特定條件的房源上市時，第一時間收到通知。"
            />
          </div>
        </div>

        {/* Properties Grid Header */}
        <div id="listings" className="flex flex-col md:flex-row justify-between items-end mb-10 gap-4 border-b border-gray-200 pb-6">
          <div>
             <h2 className="text-3xl font-bold text-gray-900 mb-2">精選房源</h2>
             <p className="text-gray-500">根據當前市場趨勢為您挑選</p>
          </div>
          <div className="flex items-center gap-3">
            {activeFilterCount > 0 && (
                <button 
                    onClick={clearFilters}
                    className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-red-600 bg-red-50 rounded-lg hover:bg-red-100 transition-colors"
                >
                    <X className="h-4 w-4" /> 清除篩選
                </button>
            )}
            <button className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors shadow-sm">
              <SlidersHorizontal className="h-4 w-4" />
              <span className="hidden sm:inline">篩選</span>
            </button>
            <button className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors shadow-sm">
              <MapPin className="h-4 w-4" />
              <span className="hidden sm:inline">地圖模式</span>
            </button>
          </div>
        </div>

        {/* Properties Grid */}
        {filteredProperties.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
            {filteredProperties.map((property) => (
              <PropertyCard 
                key={property.id} 
                property={property} 
                onClick={setSelectedProperty}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-20 mb-20 bg-white rounded-3xl border border-dashed border-gray-300">
              <div className="inline-block p-6 rounded-full bg-gray-50 mb-4">
                  <Search className="h-10 w-10 text-gray-400" />
              </div>
              <h3 className="text-xl font-bold text-gray-900">找不到符合的房源</h3>
              <p className="text-gray-500 mt-2 max-w-md mx-auto">我們找不到完全符合您需求的物件。試著調整篩選條件，或直接詢問 Mai 為您推薦。</p>
              <button 
                onClick={clearFilters}
                className="mt-6 px-6 py-2 bg-primary-600 text-white rounded-lg font-medium hover:bg-primary-700 transition-colors"
              >
                  清除所有篩選
              </button>
          </div>
        )}

        {/* Section: How it Works */}
        <div className="bg-primary-900 rounded-3xl p-12 md:p-20 text-white relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-primary-700 rounded-full filter blur-3xl opacity-20 -mr-16 -mt-16"></div>
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-500 rounded-full filter blur-3xl opacity-20 -ml-16 -mb-16"></div>
            
            <div className="relative z-10">
                <div className="text-center mb-16">
                    <h2 className="text-3xl md:text-4xl font-bold mb-6">您的購屋旅程，化繁為簡。</h2>
                    <p className="text-primary-200 text-lg max-w-2xl mx-auto">我們消除了傳統房地產的複雜性，讓您更快入住新家。</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
                    <StepCard 
                        number="01"
                        title="告訴我們您的夢想"
                        desc="與 Mai 聊天或使用智慧搜尋。描述您理想的早晨、通勤方式或您喜愛的建築風格。"
                    />
                    <StepCard 
                        number="02"
                        title="智慧預約"
                        desc="我們的 AI 會即時與房仲協調。一鍵即可預約多個物件的看屋時間。"
                    />
                    <StepCard 
                        number="03"
                        title="安心簽約"
                        desc="從出價到交屋，全程數位化管理文件與簽名。每一步都公開透明。"
                    />
                </div>
            </div>
        </div>

      </main>

      {/* Testimonials */}
      <section className="bg-white py-20 border-t border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-bold text-center text-gray-900 mb-16">深受買家信賴</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <TestimonialCard 
                    quote="Mai 比我更了解我想要什麼。我在三天內就找到了理想的公寓。"
                    author="陳淑芬"
                    role="創意總監"
                    avatar="https://randomuser.me/api/portraits/women/44.jpg"
                />
                <TestimonialCard 
                    quote="AI 估價工具給了我們出價的信心。我們最終以低於開價的價格成交，省了一大筆錢。"
                    author="王志明 & 林雅婷"
                    role="首購族"
                    avatar="https://randomuser.me/api/portraits/men/32.jpg"
                />
                <TestimonialCard 
                    quote="效率高、介面美觀，而且客服真的很有幫助。房地產交易終於跟上時代了。"
                    author="李佩珊"
                    role="建築師"
                    avatar="https://randomuser.me/api/portraits/women/65.jpg"
                />
            </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-50 border-t border-gray-200 pt-16 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
            <div className="col-span-1 md:col-span-1 lg:col-span-1">
                <div className="flex items-center mb-6">
                    <div className="h-10 w-10 bg-primary-600 rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-lg">M</div>
                    <span className="ml-3 text-2xl font-bold text-gray-900 tracking-tight">Mai Houses</span>
                </div>
                <p className="text-gray-500 text-sm leading-relaxed mb-6">
                    運用人工智慧的力量重新定義房地產。我們致力於打造以人為本、數據驅動的購屋體驗。
                </p>
                <div className="flex space-x-4">
                    {/* Social placeholders */}
                    <div className="w-8 h-8 bg-gray-200 rounded-full hover:bg-primary-500 transition-colors cursor-pointer"></div>
                    <div className="w-8 h-8 bg-gray-200 rounded-full hover:bg-primary-500 transition-colors cursor-pointer"></div>
                    <div className="w-8 h-8 bg-gray-200 rounded-full hover:bg-primary-500 transition-colors cursor-pointer"></div>
                </div>
            </div>
            <div>
                <h4 className="font-bold text-gray-900 mb-6">公司資訊</h4>
                <ul className="space-y-4 text-sm text-gray-500">
                    <li><a href="#" className="hover:text-primary-600 transition-colors">關於我們</a></li>
                    <li><a href="#" className="hover:text-primary-600 transition-colors">加入我們</a></li>
                    <li><a href="#" className="hover:text-primary-600 transition-colors">媒體報導</a></li>
                    <li><a href="#" className="hover:text-primary-600 transition-colors">聯絡我們</a></li>
                </ul>
            </div>
            <div>
                <h4 className="font-bold text-gray-900 mb-6">資源中心</h4>
                <ul className="space-y-4 text-sm text-gray-500">
                    <li><a href="#" className="hover:text-primary-600 transition-colors">市場部落格</a></li>
                    <li><a href="#" className="hover:text-primary-600 transition-colors">買房指南</a></li>
                    <li><a href="#" className="hover:text-primary-600 transition-colors">賣房指南</a></li>
                    <li><a href="#" className="hover:text-primary-600 transition-colors">房貸試算</a></li>
                </ul>
            </div>
             <div>
                <h4 className="font-bold text-gray-900 mb-6">訂閱電子報</h4>
                <p className="text-sm text-gray-500 mb-4">加入我們，獲取最新的市場動態。</p>
                <div className="flex">
                    <input type="email" placeholder="您的電子郵件" className="flex-1 px-4 py-2 bg-white border border-gray-200 rounded-l-lg text-sm focus:outline-none focus:border-primary-500"/>
                    <button className="bg-primary-600 text-white px-4 py-2 rounded-r-lg hover:bg-primary-700 transition-colors">
                        <ArrowRight className="h-4 w-4" />
                    </button>
                </div>
            </div>
          </div>
          <div className="pt-8 border-t border-gray-200 flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-gray-400 text-sm">
                &copy; 2024 Mai Houses Inc. All rights reserved.
            </div>
            <div className="flex space-x-6 text-sm text-gray-500">
                <a href="#" className="hover:text-gray-900">隱私權政策</a>
                <a href="#" className="hover:text-gray-900">服務條款</a>
                <a href="#" className="hover:text-gray-900">Cookie 設定</a>
            </div>
          </div>
        </div>
      </footer>

      {/* Property Detail Modal */}
      {selectedProperty && (
        <div className="fixed inset-0 z-50 overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
          <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 bg-gray-900 bg-opacity-75 transition-opacity backdrop-blur-sm" aria-hidden="true" onClick={() => setSelectedProperty(null)}></div>
            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            
            <div className="inline-block align-bottom bg-white rounded-2xl text-left overflow-hidden shadow-2xl transform transition-all sm:my-8 sm:align-middle sm:max-w-4xl sm:w-full animate-in fade-in zoom-in duration-300">
              <div className="grid grid-cols-1 md:grid-cols-2 h-full md:h-[500px]">
                  <div className="relative h-64 md:h-full">
                    <img src={selectedProperty.imageUrl} alt={selectedProperty.title} className="w-full h-full object-cover" />
                    <button 
                        onClick={() => setSelectedProperty(null)}
                        className="absolute top-4 left-4 bg-black/20 backdrop-blur-md p-2 rounded-full text-white hover:bg-black/40 transition-colors md:hidden"
                    >
                        <X className="h-6 w-6" />
                    </button>
                  </div>
                  
                  <div className="p-8 flex flex-col h-full overflow-y-auto">
                    <div className="flex justify-between items-start mb-6">
                        <div>
                            <span className="inline-block px-3 py-1 bg-primary-50 text-primary-700 rounded-full text-xs font-bold uppercase tracking-wide mb-2">{getPropertyTypeLabel(selectedProperty.type)}</span>
                            <h3 className="text-2xl font-bold text-gray-900 leading-tight" id="modal-title">{selectedProperty.title}</h3>
                            <p className="text-gray-500 flex items-center mt-2"><MapPin className="h-4 w-4 mr-1 text-gray-400"/> {selectedProperty.location}</p>
                        </div>
                        <button 
                            onClick={() => setSelectedProperty(null)}
                            className="bg-gray-100 p-2 rounded-full text-gray-500 hover:bg-gray-200 transition-colors hidden md:block"
                        >
                            <X className="h-5 w-5" />
                        </button>
                    </div>

                    <div className="grid grid-cols-3 gap-4 py-6 border-t border-b border-gray-100 mb-6">
                        <div className="text-center">
                            <div className="text-xl font-bold text-gray-900">{selectedProperty.beds}</div>
                            <div className="text-xs text-gray-400 uppercase font-medium">房</div>
                        </div>
                        <div className="text-center border-l border-gray-100">
                            <div className="text-xl font-bold text-gray-900">{selectedProperty.baths}</div>
                            <div className="text-xs text-gray-400 uppercase font-medium">衛</div>
                        </div>
                        <div className="text-center border-l border-gray-100">
                            <div className="text-xl font-bold text-gray-900">{selectedProperty.sqft}</div>
                            <div className="text-xs text-gray-400 uppercase font-medium">坪</div>
                        </div>
                    </div>
                    
                    <div className="mb-8 flex-grow">
                        <h4 className="text-sm font-bold text-gray-900 uppercase tracking-wide mb-3">關於此房源</h4>
                        <p className="text-gray-600 leading-relaxed text-sm md:text-base">{selectedProperty.description}</p>
                    </div>

                    <div className="mt-auto">
                        <div className="flex items-center justify-between mb-6">
                            <div>
                                <span className="text-sm text-gray-400">售價</span>
                                <div className="text-3xl font-bold text-primary-600">NT$ {selectedProperty.price.toLocaleString()}</div>
                            </div>
                        </div>
                        <div className="flex gap-3">
                            <button type="button" className="flex-1 bg-primary-600 text-white rounded-xl py-3 px-4 font-bold shadow-lg hover:bg-primary-700 transform transition-transform active:scale-95">
                                預約賞屋
                            </button>
                            <button type="button" className="flex-1 bg-white border border-gray-200 text-gray-700 rounded-xl py-3 px-4 font-bold hover:bg-gray-50 transition-colors">
                                聯絡房仲
                            </button>
                        </div>
                    </div>
                  </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Chat Widget */}
      <ChatWidget 
        isOpen={isChatOpen} 
        onClose={() => setIsChatOpen(false)} 
        onFilterUpdate={handleFilterUpdate}
      />

       {/* Chat Floating Button (if closed) */}
       {!isChatOpen && (
        <button
            onClick={() => setIsChatOpen(true)}
            className="fixed bottom-6 right-6 px-5 py-3 bg-primary-600 text-white rounded-full shadow-xl shadow-primary-600/20 hover:bg-primary-700 hover:shadow-2xl transition-all duration-300 z-40 flex items-center gap-3 group"
        >
            <div className="relative">
              <Bot className="h-6 w-6 group-hover:rotate-12 transition-transform" />
              <span className="absolute -top-1 -right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-